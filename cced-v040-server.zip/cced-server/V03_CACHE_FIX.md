# CCED v0.3 cache fix

The v0.2 feature code is preserved. This release changes only the PWA service-worker cache version and forces an update check, preventing an older cached CCED interface from being served by the browser.
