# CCED v0.3.4 — additive feature build

## Preservation rule
Existing layout, navigation structure, visual language, and existing features were preserved. This release adds functionality only.

## Added
- College section in the existing navigation.
- KTU Semester 1 academic knowledge-map flow.
- Algorithmic Thinking with Python (UCEST105) learning map with four module groups and topic checklists.
- Topic-level completion tracking stored in the existing local state.
- Module/course progress calculation.
- Add-to-Priority bridge from College learning items into the existing Priority/Activity system.
- Existing Today date selection, current/next class behavior, timetable editor, API-key UI, AI flow, and notifications remain in place.
- Service-worker cache version bumped so the new build is not hidden behind the previous cached version.

## Academic-source note
The KTU 2024 curriculum page is the official source of curriculum information. The UCEST105 topic organization is based on a KTU 2024 course resource published by Dr. Binu V. P., and should be cross-checked against the official syllabus document before being treated as authoritative syllabus text.
