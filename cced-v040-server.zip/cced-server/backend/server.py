"""
CCED backend — single shared SQLite database serving one JSON state document.

Why this shape: the CCED frontend already treats its entire app state
(timetable, activities, settings, apiKeys, notifications, collegeProgress)
as one JSON object that it used to keep in localStorage. Moving that same
object into a one-row SQLite table is the smallest change that gets you a
single, real, shared database — reachable from desktop and phone alike —
without a risky rewrite of the frontend's data model.

Run with:
    python -m venv .venv && source .venv/bin/activate   (first time only)
    pip install fastapi uvicorn
    python server.py

The server binds 0.0.0.0:8000, so it's reachable from other devices on the
same WiFi at http://<this-computer's-LAN-IP>:8000
"""

import json
import sqlite3
import threading
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

DB_PATH = Path(__file__).parent / "cced.db"
FRONTEND_DIR = Path(__file__).parent.parent / "dist"

# Default state — mirrors the frontend's `seed` object, used only the
# very first time the database is created (i.e. first run ever).
SEED_STATE = {
    "timetable": [
        {"id": "t1", "day": 4, "start": "09:00", "end": "10:00", "subject": "Programming", "room": "Lab 1"},
        {"id": "t2", "day": 4, "start": "10:15", "end": "11:15", "subject": "Engineering Mathematics", "room": "A-204"},
        {"id": "t3", "day": 4, "start": "11:30", "end": "12:30", "subject": "Physics", "room": "B-102"},
        {"id": "t4", "day": 5, "start": "09:00", "end": "10:00", "subject": "Digital Electronics", "room": "A-201"},
    ],
    "apiKeys": [],
    "notifications": [],
    "collegeProgress": {},
    "settings": {"notificationsEnabled": True, "aiProvider": "OpenRouter", "aiModel": "openai/gpt-4o-mini"},
    "activities": [],
}

_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS app_state ("
        "  id INTEGER PRIMARY KEY CHECK (id = 1),"
        "  data TEXT NOT NULL,"
        "  updated_at TEXT DEFAULT CURRENT_TIMESTAMP"
        ")"
    )
    conn.commit()
    return conn


def read_state() -> dict:
    conn = get_conn()
    try:
        row = conn.execute("SELECT data FROM app_state WHERE id = 1").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO app_state (id, data) VALUES (1, ?)",
                (json.dumps(SEED_STATE),),
            )
            conn.commit()
            return json.loads(json.dumps(SEED_STATE))
        return json.loads(row[0])
    finally:
        conn.close()


def write_state(state: dict) -> None:
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO app_state (id, data, updated_at) VALUES (1, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP",
            (json.dumps(state),),
        )
        conn.commit()
    finally:
        conn.close()


app = FastAPI(title="CCED backend")

# Same-LAN devices (phone) hit this from a different origin than desktop
# browser dev tools might use, so keep CORS open on the local network.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/state")
def get_state():
    with _lock:
        return read_state()


@app.put("/api/state")
async def put_state(request: Request):
    body = await request.json()
    if not isinstance(body, dict):
        raise HTTPException(400, "State must be a JSON object.")
    with _lock:
        write_state(body)
    return {"ok": True}


@app.get("/api/health")
def health():
    return {"ok": True}


# Serve the built frontend (index.html, src/*, sw.js, icon.svg, manifest)
# so the same server that hosts the database also hosts the app —
# one address for desktop and mobile to open.
if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
