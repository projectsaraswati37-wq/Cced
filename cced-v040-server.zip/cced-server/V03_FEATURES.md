# CCED v0.3.3 — Feature integration

Built from the working v0.3.2 source without redesigning the existing layout.

- Clock/date are explicitly calculated in Asia/Kolkata (IST).
- Hero date automatically follows the current IST date when the app opens and while it remains open.
- Current/next timetable sessions refresh from the IST clock.
- Date picker changes the academic day shown by the hero/timetable.
- Timetable is grouped into Monday–Sunday modules and each class can be deleted.
- Timetable add flow includes day, room, start and end time.
- Settings navigation is functional.
- Browser notification permission and a real test notification are available.
- Deadline reminders are derived from activity deadlines and surfaced through browser/service-worker notifications while the app is running.
- OpenRouter API key adapter is functional: save provider/key/model in Settings, then use the AI button for live AI requests.
- Mock AI remains available when no key is configured or live AI fails.
- API keys are stored locally for this browser-only MVP. Do not use this approach for production secrets.
- Service worker paths are relative and cache version is bumped to avoid the previous stale-cache issue.
