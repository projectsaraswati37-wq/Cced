#!/usr/bin/env bash
# CCED — one-command build + run.
#
# What this does:
#   1. Builds the frontend (npm) into dist/
#   2. Sets up a Python venv for the backend (first run only)
#   3. Starts the FastAPI server on 0.0.0.0:8000
#
# Once running, open:
#   http://localhost:8000            (this computer)
#   http://<this-computer-LAN-IP>:8000   (phone, same WiFi)
#
# Find your LAN IP with `ip addr` (Linux), `ipconfig getifaddr en0` (Mac),
# or `ipconfig` (Windows, look for IPv4 Address).

set -e
cd "$(dirname "$0")"

echo "==> Installing frontend dependencies..."
npm install

echo "==> Building frontend..."
npm run build

echo "==> Setting up backend virtual environment (if needed)..."
cd backend
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -q -r requirements.txt

echo "==> Starting CCED server on http://0.0.0.0:8000 ..."
echo "    Desktop: http://localhost:8000"
echo "    Phone (same WiFi): http://<this computer's LAN IP>:8000"
python server.py
