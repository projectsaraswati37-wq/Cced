# CCED MVP

CCED is a mobile-first personal academic operating system.

## Run without npm (Termux / static hosting)

```bash
python -m http.server 8080 --bind 127.0.0.1
```

Open `http://127.0.0.1:8080`.

## Run with Vite

```bash
npm install
npm run dev
```

Open the local Vite URL on your phone or computer.

## Build

```bash
npm run build
npm run preview
```

The `dist/` directory is a static PWA build suitable for static hosting.

## Current MVP

- Today dashboard
- Timetable
- Activity management
- Checkpoints and progress
- Deterministic priority engine
- Deterministic risk engine
- Deadline-aware status
- Mock AI natural-language activity entry
- Local-first persistence via localStorage
- PWA/service worker
- No authentication
- No cloud database
- No exposed AI key

## AI adapter boundary

The current `interpretAI()` function is deliberately a mock adapter. Replace it later with a server-side endpoint that returns a validated proposal. Never put an OpenRouter key in the browser.

## Important

This is an MVP foundation, not a production backend. Browser storage can be cleared by the user/browser. Notifications and a secure server-side AI proxy should be added before treating it as a production personal system.
