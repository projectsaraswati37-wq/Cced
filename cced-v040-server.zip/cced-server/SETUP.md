# CCED v0.4.0 — setup (desktop + phone, one database)

## What changed from v0.3.4 / v0.3.5
- Merged the College/KTU tracker (from v0.3.4) with the AI markdown-fallback
  parser and live clock (from v0.3.5).
- Replaced `localStorage` with a small **FastAPI + SQLite** backend
  (`backend/server.py`, `backend/cced.db`). All app state — timetable,
  activities, settings, API keys, notifications, college progress — now
  lives in one shared database file instead of being split per-browser.
- The server also hosts the built frontend, so desktop and phone both
  open the *same* URL and see the *same* data.

## First-time setup

**Requirements:** Node.js + npm, Python 3.9+

```bash
cd cced-server
./start.sh
```

This will:
1. `npm install` and `npm run build` the frontend into `dist/`
2. Create a Python virtual environment in `backend/.venv` and install FastAPI/uvicorn
3. Start the server on `0.0.0.0:8000`

Leave that terminal running — closing it stops the server.

## Opening it

- **On your desktop:** go to `http://localhost:8000`
- **On your phone:** both devices must be on the **same WiFi network**.
  Find your desktop's LAN IP:
  - Linux: `ip addr` (look for something like `192.168.x.x`)
  - Mac: `ipconfig getifaddr en0`
  - Windows: `ipconfig` → "IPv4 Address"

  Then on your phone's browser, go to `http://<that IP>:8000` — e.g.
  `http://192.168.1.42:8000`

  Your desktop's LAN IP can change (e.g. after a router restart), so if
  the phone stops connecting, re-check the IP.

## Subsequent runs

Once set up, you can just run `./start.sh` again — it reinstalls/rebuilds
each time (fast, since deps are cached), so this is safe to leave as
your one command to start CCED.

If you'd rather skip the rebuild step and just restart the server:
```bash
cd backend
source .venv/bin/activate
python server.py
```
(only do this after you've run `./start.sh` at least once, so `dist/`
and the venv already exist)

## Your data

Everything lives in `backend/cced.db`, a single SQLite file. Back it up
by copying that one file. There is currently **no login/password** —
anyone on your WiFi network who knows your desktop's IP can view or edit
your data. That's fine for a home network; if you ever move this beyond
your house, add auth first.

## Known limitation

This only works while your desktop is on and both devices share the same
WiFi. It won't be reachable from mobile data or a different network. If
you later want that, the backend code here can be redeployed to a small
cloud host with minimal changes — ask and I can help with that upgrade.
