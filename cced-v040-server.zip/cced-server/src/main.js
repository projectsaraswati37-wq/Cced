const TZ = "Asia/Kolkata";
const API_BASE = ""; // same origin — server serves both API and static files
const seed = {
  timetable: [
    {id:"t1", day:4, start:"09:00", end:"10:00", subject:"Programming", room:"Lab 1"},
    {id:"t2", day:4, start:"10:15", end:"11:15", subject:"Engineering Mathematics", room:"A-204"},
    {id:"t3", day:4, start:"11:30", end:"12:30", subject:"Physics", room:"B-102"},
    {id:"t4", day:5, start:"09:00", end:"10:00", subject:"Digital Electronics", room:"A-201"}
  ],
  apiKeys: [],
  notifications: [],
  collegeProgress: {},
  settings: {notificationsEnabled:true, aiProvider:"OpenRouter", aiModel:"openai/gpt-4o-mini"},
  activities: [
    {id:"a1",title:"Physics Record",description:"Experiment 4 record submission.",subject:"Physics",type:"Submission",deadline:datePlus(2),importance:5,effort:3,status:"In Progress",
      checkpoints:[{id:"c1",title:"Complete Experiment 4",done:true},{id:"c2",title:"Write Observation",done:true},{id:"c3",title:"Complete Record",done:false},{id:"c4",title:"Review",done:false},{id:"c5",title:"Submit",done:false}]},
    {id:"a2",title:"Mathematics Assignment",description:"Complete assigned problems.",subject:"Engineering Mathematics",type:"Assignment",deadline:datePlus(5),importance:4,effort:2,status:"Not Started",
      checkpoints:[{id:"c1",title:"Solve problems",done:false},{id:"c2",title:"Check answers",done:false},{id:"c3",title:"Submit",done:false}]}
  ]
};
function datePlus(days){const d=new Date();d.setHours(23,59,0,0);d.setDate(d.getDate()+days);return d.toISOString()}
function normalizeState(s){
  return s?{...seed,...s,settings:{...seed.settings,...(s.settings||{})},apiKeys:Array.isArray(s.apiKeys)?s.apiKeys:[],notifications:Array.isArray(s.notifications)?s.notifications:[],collegeProgress:s.collegeProgress&&typeof s.collegeProgress==="object"?s.collegeProgress:{},timetable:Array.isArray(s.timetable)?s.timetable:seed.timetable,activities:Array.isArray(s.activities)?s.activities:seed.activities}:seed;
}

// --- Server-backed persistence -------------------------------------------
// The whole app state lives in one shared SQLite row on the backend, so
// desktop and any phone on the same WiFi see the same data. We keep a
// local in-memory copy (`state`) for instant UI, and push it to the
// server on every change. If the server is unreachable, CCED keeps
// working from the in-memory copy and retries the write on the next
// change, so a flaky WiFi moment never breaks the UI — but note that
// writes made while offline don't reach the shared database until the
// server is reachable again.
let state = seed;
let serverReachable = true;
let saveTimer = null;

async function loadFromServer(){
  try{
    const res = await fetch(`${API_BASE}/api/state`);
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    state = normalizeState(data);
    serverReachable = true;
  }catch(err){
    serverReachable = false;
    console.warn("CCED: could not reach server, using local defaults.", err);
  }
  render();
}

function save(){
  // Debounce rapid successive saves (e.g. checkbox toggling) into one request.
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async ()=>{
    try{
      const res = await fetch(`${API_BASE}/api/state`, {
        method: "PUT",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(state)
      });
      if(!res.ok) throw new Error(`HTTP ${res.status}`);
      if(!serverReachable){ serverReachable = true; render(); }
    }catch(err){
      if(serverReachable){ serverReachable = false; render(); }
      console.warn("CCED: save failed, will retry on next change.", err);
    }
  }, 150);
}

let view="today", selectedDateKey=todayKey(), currentAIProposal=null, lastLiveMinute="";
const app=document.querySelector("#app");
const uid=()=>crypto.randomUUID?.()||Date.now()+"-"+Math.random();
const DAYS=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
function progress(a){return a.checkpoints?.length?Math.round(a.checkpoints.filter(c=>c.done).length/a.checkpoints.length*100):a.status==="Completed"?100:0}
function remainingHours(a){return Math.max(0,(a.checkpoints||[]).filter(c=>!c.done).length*.75)}
function priority(a){const hours=Math.max(0,(new Date(a.deadline)-Date.now())/36e5),deadline=hours<=24?100:hours<=72?80:hours<=168?55:25,rem=100-progress(a),effort=Math.min(100,(a.effort||1)*20);return Math.round(deadline*.4+(a.importance||1)*20*.3+rem*.15+effort*.1+50*.05)}
function priorityLabel(s){return s>=80?["Critical","critical"]:s>=60?["High","high"]:s>=40?["Medium","medium"]:["Low","low"]}
function risk(a){const hours=Math.max(0,(new Date(a.deadline)-Date.now())/36e5),work=remainingHours(a);if(work===0)return 0;if(hours<work)return 3;if(hours<work*2)return 2;return 1}
function dueText(iso){const ms=new Date(iso)-Date.now(),d=Math.ceil(ms/86400000);if(d<0)return "Overdue";if(d===0)return "Due today";if(d===1)return "Due tomorrow";return `Due in ${d} days`}
function escape(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function partsInIST(date=new Date()){return new Intl.DateTimeFormat("en-CA",{timeZone:TZ,year:"numeric",month:"2-digit",day:"2-digit",weekday:"long",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(date).reduce((o,p)=>(o[p.type]=p.value,o),{})}
function todayKey(){const p=partsInIST();return `${p.year}-${p.month}-${p.day}`}
function dateKeyFromInput(value){return /^\d{4}-\d{2}-\d{2}$/.test(value)?value:todayKey()}
function dateParts(key){const [year,month,day]=key.split("-").map(Number);return {year,month,day,date:new Date(Date.UTC(year,month-1,day,12))}}
function dayForKey(key){return dateParts(key).date.getUTCDay()}
function formatDate(key){const {date}=dateParts(key);return date.toLocaleDateString("en-IN",{month:"short",day:"numeric",year:"numeric",timeZone:"UTC"})}
function formatFullDate(key){const {date}=dateParts(key);return date.toLocaleDateString("en-IN",{weekday:"long",month:"long",day:"numeric",year:"numeric",timeZone:"UTC"})}
function istClock(){const p=partsInIST();return `${p.hour}:${p.minute}:${p.second}`}
function selectedSchedule(){const day=dayForKey(selectedDateKey);return state.timetable.filter(x=>x.day===day).sort((a,b)=>a.start.localeCompare(b.start))}
function scheduleNow(){const isToday=selectedDateKey===todayKey(),now=partsInIST(),currentHHMM=`${now.hour}:${now.minute}`,rows=selectedSchedule().map(x=>({...x,active:isToday&&currentHHMM>=x.start&&currentHHMM<x.end,future:isToday&&currentHHMM<x.start}));return {current:rows.find(x=>x.active)||null,next:rows.find(x=>x.future)||null}}
function activityCard(a,compact=false){const p=progress(a),[label,cls]=priorityLabel(priority(a));return `<div class="activity"><div class="row"><div><strong>${escape(a.title)}</strong><div class="subtle">${escape(a.subject||"")} · ${escape(a.type||"")}</div></div><span class="pill ${cls}">${label}</span></div>${!compact?`<div class="subtle" style="margin-top:9px">${escape(a.description||"")}</div>`:""}<div class="progress"><i style="width:${p}%"></i></div><div class="row"><small>${p}% complete</small><small>${dueText(a.deadline)}</small></div>${!compact?`<button class="btn" style="margin-top:11px" onclick="openActivity('${a.id}')">Open activity</button>`:""}</div>`}
function ensureNotificationPermission(){if(!state.settings.notificationsEnabled||!("Notification"in window))return Promise.resolve("unsupported");if(Notification.permission==="default")return Notification.requestPermission();return Promise.resolve(Notification.permission)}
async function showSystemNotification(title,body,tag){if(!state.settings.notificationsEnabled||!("Notification"in window))return;const permission=Notification.permission==="granted"?"granted":await ensureNotificationPermission();if(permission!=="granted")return;try{if("serviceWorker"in navigator){const reg=await navigator.serviceWorker.ready;await reg.showNotification(title,{body,tag,icon:"./icon.svg",badge:"./icon.svg"});}else new Notification(title,{body,tag});}catch{try{new Notification(title,{body,tag})}catch{}}}
function refreshNotifications(){if(!state.settings.notificationsEnabled)return;state.notifications=state.notifications||[];const now=Date.now();state.activities.forEach(a=>{const ms=new Date(a.deadline)-now;if(ms<=0||ms>5*86400000)return;const bucket=ms<=86400000?"24h":"5d",id=a.id+"-"+bucket;if(!state.notifications.some(n=>n.id===id))state.notifications.push({id,activityId:a.id,title:a.title+" deadline",body:dueText(a.deadline)+". "+(100-progress(a))+"% incomplete.",read:false,createdAt:new Date().toISOString()})});save()}
async function fireNotifications(){if(!state.settings.notificationsEnabled)return;const pending=(state.notifications||[]).filter(n=>!n.read);for(const n of pending.slice(-3)){await showSystemNotification("CCED",n.body,n.id);n.read=true}if(pending.length)save()}
function connectionBadge(){return serverReachable?"":'<div class="pill high" style="margin-bottom:12px">⚠ Offline — changes will sync once the server is reachable</div>'}
function render(){const nowParts=partsInIST(),long=formatDate(selectedDateKey),day=formatFullDate(selectedDateKey),time=`${nowParts.hour}:${nowParts.minute}:${nowParts.second} IST`;app.innerHTML=`<main class="shell"><header class="topbar"><div><div class="brand">CCED</div><div class="subtle">Personal Academic OS</div></div><nav class="nav">${["today","timetable","activities","priority","progress","college","settings"].map(v=>`<button class="${view===v?"active":""}" onclick="setView('${v}')">${v[0].toUpperCase()+v.slice(1)}</button>`).join("")}</nav></header>${connectionBadge()}${view==="today"?today(long,day,time):view==="timetable"?timetable():view==="activities"?activities():view==="priority"?priorityView():view==="progress"?progressView():view==="college"?collegeView():settingsView()}<button class="fab" onclick="openAI()">✦ AI</button></main>`}
function sessionCard(which,x,isToday){
  const title=which==="current"?"CURRENT":"NEXT";
  const fallback=which==="current"?(isToday?"No class right now.":"Current session is only live for today."):(isToday?"No more classes today.":"No upcoming session for this selected date.");
  return `<section class="card" id="cced-${which}-card" onclick="classAction('${which}')" style="cursor:pointer"><h3 class="section-title">${title}</h3>${x?`<div><strong>${escape(x.subject)}</strong><div class="subtle">${x.start}–${x.end} · ${escape(x.room)}</div><div class="pill" style="margin-top:10px">${which==="current"?"● Live now":"Upcoming"}</div></div>`:`<div class="empty">${fallback}</div>`}</section>`;
}
function today(long,day,time){
  const schedule=selectedSchedule(),{current,next}=scheduleNow(),urgent=[...state.activities].sort((a,b)=>priority(b)-priority(a)).slice(0,3),isToday=selectedDateKey===todayKey();
  return `<section class="hero" onclick="pickDate()" style="cursor:pointer"><div class="eyebrow">${escape(day)}</div><h1>${escape(long)}</h1><div class="subtle" style="color:#aaa">${isToday?`IST <span id="cced-clock">${time}</span> · `:""}Tap to choose a date · Your academic day at a glance.</div></section><div class="grid"><div class="stack">${sessionCard("current",current,isToday)}${sessionCard("next",next,isToday)}<section class="card"><h3 class="section-title">ATTENTION</h3>${urgent.map(a=>activityCard(a,true)).join("")||'<div class="empty">Nothing urgent. You are clear.</div>'}</section></div><aside class="card"><h3 class="section-title">${isToday?"TODAY":"SELECTED DAY"}’S TIMETABLE</h3>${schedule.length?schedule.map(x=>`<div class="timeitem"><div class="time">${x.start}–${x.end}</div><strong>${escape(x.subject)}</strong><div class="subtle">${escape(x.room)}</div></div>`).join(""):'<div class="empty">No timetable entries.</div>'}</aside></div>`;
}
function timetable(){return `<section class="card"><div class="row"><div><h2 style="margin:0">Timetable</h2><div class="subtle">Reference schedule</div></div><button class="btn dark" onclick="addClass()">Add class</button></div><div class="stack" style="margin-top:16px">${[1,2,3,4,5,6,0].map(day=>{const rows=state.timetable.filter(x=>x.day===day).sort((a,b)=>a.start.localeCompare(b.start));return `<div class="muted-box"><div class="row"><strong>${DAYS[day]}</strong><span class="subtle">${rows.length} ${rows.length===1?"class":"classes"}</span></div>${rows.length?rows.map(x=>`<div style="padding-top:9px"><b>${x.start}–${x.end}</b> · ${escape(x.subject)} <span class="subtle">· ${escape(x.room)}</span><button class="btn danger" style="float:right;padding:5px 8px" onclick="deleteClass('${x.id}')">Delete</button></div>`).join(""):'<div class="subtle" style="padding-top:9px">No classes scheduled.</div>'}</div>`}).join("")}</div></section>`}
function activities(){return `<section class="card"><div class="row"><div><h2 style="margin:0">Activities</h2><div class="subtle">${state.activities.length} active records</div></div><button class="btn dark" onclick="manualActivity()">+ Activity</button></div><div style="margin-top:16px">${state.activities.map(a=>activityCard(a)).join("")||'<div class="empty">No activities yet.</div>'}</div></section>`}
function priorityView(){const sorted=[...state.activities].sort((a,b)=>priority(b)-priority(a));return `<section class="card"><h2 style="margin:0">Priority</h2><div class="subtle">Deterministic scoring; no AI required. Checkpoints are interactive and update progress immediately.</div><div style="margin-top:16px">${sorted.map((a,i)=>{const[l,c]=priorityLabel(priority(a));return `<div class="activity"><div class="row"><div><b>#${i+1} ${escape(a.title)}</b><div class="subtle">${escape(a.subject)} · ${dueText(a.deadline)}</div></div><span class="pill ${c}">${l}</span></div><div class="subtle" style="margin-top:9px">Due pressure · ${Math.max(0,Math.round((new Date(a.deadline)-Date.now())/36e5))}h remaining · ${100-progress(a)}% incomplete</div>${(a.checkpoints||[]).length?`<div style="margin-top:10px">${a.checkpoints.map(c=>`<label class="check"><input type="checkbox" ${c.done?'checked':''} onchange="toggleCheck('${a.id}','${c.id}',this.checked)"><span>${escape(c.title)}</span></label>`).join('')}</div>`:''}<div class="progress"><i style="width:${progress(a)}%"></i></div><div class="row"><small>${progress(a)}% complete</small><button class="btn" style="margin-top:10px" onclick="openActivity('${a.id}')">Open</button></div></div>`}).join("")||'<div class="empty">No priority items yet.</div>'}</div></section>`}
function progressView(){const total=state.activities.length,avg=total?Math.round(state.activities.reduce((s,a)=>s+progress(a),0)/total):0;return `<div class="grid"><section class="card"><div class="subtle">OVERALL PROGRESS</div><div class="metric">${avg}%</div><div class="progress"><i style="width:${avg}%"></i></div><div class="subtle">${state.activities.filter(a=>progress(a)===100).length} completed of ${total}</div></section><section class="card"><div class="subtle">RISK</div><div class="stack" style="margin-top:12px">${state.activities.map(a=>`<div><div class="row"><b>${escape(a.title)}</b><span>${["","Low","Medium","High"][risk(a)]}</span></div><div class="riskbar">${[1,2,3].map(n=>`<span class="${n<=risk(a)?"on":""}"></span>`).join("")}</div></div>`).join("")||'<div class="empty">No activities.</div>'}</div></section></div>`}
const COLLEGE_DATA={
  institution:"APJ Abdul Kalam Technological University",
  regulation:"B.Tech 2024 Curriculum",
  branch:"Computer Science",
  semester:1,
  courses:[{
    id:"ucest105",code:"UCEST105",name:"Algorithmic Thinking with Python",credits:null,type:"Course",
    source:"KTU 2024 scheme course reference; module/topic structure cross-checked against faculty course notes. Verify against the official syllabus document before treating as authoritative.",
    modules:[
      {id:"m1",title:"Problem Solving & Python Foundations",topics:["Problem and computer programming problem","Problem solving strategies","Heuristic method","Trial and error","Means-end analysis","Backtracking","Problem solving process","Identifiers, variables and keywords","Basic data types and type conversions","Operators","Operator precedence and expression evaluation","input() and print() functions","Built-in functions, modules and packages","Strings","Errors in Python programs"]},
      {id:"m2",title:"Algorithmic Thinking",topics:["Program development","Introduction to algorithmic thinking","Algorithms","Pseudocode","Why write pseudocode before code","Flowcharts","Algorithm, flowchart and pseudocode examples","RAPTOR and visual algorithm prototyping"]},
      {id:"m3",title:"Control Statements & Python Data Structures",topics:["Conditional statements","while and for loops","Nested loops","break, continue and pass","Sequences","Lists","List functions and methods","Tuples","Sets and frozen sets","Strings","Dictionaries and dictionary functions","Comparison of list, tuple, set and dictionary","Problem decomposition and modularization","Lambda functions","Defining and calling functions","Global and local variables","Recursion","Call stack","Iteration versus recursion"]},
      {id:"m4",title:"Computational Approaches to Problem Solving",topics:["Brute-force approach","Divide-and-conquer approach","Merge sort","Dynamic programming","Memoization and tabulation","Fibonacci using dynamic programming","Recursion versus dynamic programming","Greedy algorithm approach","Characteristics of greedy algorithms","Greedy versus dynamic programming","Randomized algorithm approach","Random sampling"]}
    ]
  }]
};
let collegeCourseId=null,collegeModuleId=null;
function collegeProgress(course){let all=course.modules.flatMap(m=>m.topics.map(t=>`${m.id}:${t}`));let done=all.filter(k=>state.collegeProgress?.[course.id]?.[k]).length;return all.length?Math.round(done/all.length*100):0}
function moduleProgress(course,m){let done=m.topics.filter(t=>state.collegeProgress?.[course.id]?.[`${m.id}:${t}`]).length;return m.topics.length?Math.round(done/m.topics.length*100):0}
function collegeView(){const course=COLLEGE_DATA.courses.find(c=>c.id===collegeCourseId);const mod=course?.modules.find(m=>m.id===collegeModuleId);if(course&&mod)return collegeModuleView(course,mod);if(course)return collegeCourseView(course);return `<section class="card"><div class="row"><div><h2 style="margin:0">College</h2><div class="subtle">KTU academic knowledge map</div></div></div><div class="stack" style="margin-top:16px"><div class="muted-box"><b>KTU · Semester 1</b><div class="subtle">Initial scope only. Academic content is separated from the existing task system.</div></div><button class="activity" style="text-align:left;border:1px solid #e8e8e5" onclick="openCollegeCourse('ucest105')"><div class="row"><div><b>Algorithmic Thinking with Python</b><div class="subtle">UCEST105 · Semester 1</div></div><span class="pill">Open</span></div></button><div class="subtle">Source integrity: course/module data is marked for verification against the official KTU syllabus before being treated as authoritative.</div></div></section>`}
function collegeCourseView(course){return `<section class="card"><div class="row"><div><button class="btn" onclick="backCollege()">← College</button><h2 style="margin:14px 0 4px">${escape(course.name)}</h2><div class="subtle">${escape(course.code)} · Semester 1 · ${collegeProgress(course)}% complete</div></div><span class="pill">KTU 2024</span></div><div class="progress"><i style="width:${collegeProgress(course)}%"></i></div><div class="muted-box"><b>Learning map</b><div class="subtle">Open a module to see what to learn and track each topic.</div></div><div class="stack" style="margin-top:12px">${course.modules.map(m=>`<button class="activity" style="text-align:left" onclick="openCollegeModule('${course.id}','${m.id}')"><div class="row"><div><b>${escape(m.title)}</b><div class="subtle">${m.topics.length} learning items</div></div><span class="pill">${moduleProgress(course,m)}%</span></div><div class="progress"><i style="width:${moduleProgress(course,m)}%"></i></div></button>`).join('')}</div><div class="muted-box" style="margin-top:12px"><b>Source</b><div class="subtle">${escape(course.source)}</div></div></section>`}
function collegeModuleView(course,m){const p=moduleProgress(course,m);return `<section class="card"><div class="row"><div><button class="btn" onclick="backCollegeCourse()">← ${escape(course.name)}</button><h2 style="margin:14px 0 4px">${escape(m.title)}</h2><div class="subtle">${p}% complete · ${m.topics.filter(t=>state.collegeProgress?.[course.id]?.[`${m.id}:${t}`]).length}/${m.topics.length} topics</div></div><span class="pill">Module</span></div><div class="progress"><i style="width:${p}%"></i></div><div class="stack" style="margin-top:12px">${m.topics.map(t=>{const key=`${m.id}:${t}`,done=!!state.collegeProgress?.[course.id]?.[key],safe=encodeURIComponent(t);return `<div class="activity"><label class="check"><input type="checkbox" ${done?'checked':''} onchange="toggleCollegeTopic('${course.id}','${m.id}','${safe}',this.checked)"><span><b>${escape(t)}</b><div class="subtle">${done?'Completed':'Learn this topic'}</div></span></label><div class="row" style="margin-top:8px"><span class="subtle">Academic learning item</span><button class="btn" onclick="addCollegePriority('${course.id}','${m.id}','${safe}')">＋ Add to Priority</button></div></div>`}).join('')}</div></section>`}
window.openCollegeCourse=id=>{collegeCourseId=id;collegeModuleId=null;view='college';render()}
window.openCollegeModule=(cid,mid)=>{collegeCourseId=cid;collegeModuleId=mid;view='college';render()}
window.backCollege=()=>{collegeCourseId=null;collegeModuleId=null;render()}
window.backCollegeCourse=()=>{collegeModuleId=null;render()}
window.toggleCollegeTopic=(cid,mid,encoded,val)=>{const topic=decodeURIComponent(encoded);state.collegeProgress[cid] ||= {};state.collegeProgress[cid][`${mid}:${topic}`]=!!val;save();render()}
window.addCollegePriority=(cid,mid,encoded)=>{const course=COLLEGE_DATA.courses.find(c=>c.id===cid),m=course?.modules.find(x=>x.id===mid),topic=decodeURIComponent(encoded);if(!course||!m)return;const existing=state.activities.find(a=>a.collegeSource?.topic===topic&&a.collegeSource?.courseId===cid);if(existing){view='priority';render();return}const a={id:uid(),title:topic,description:`Learning item from ${course.name}, ${m.title}.`,subject:course.name,type:'Study task',deadline:datePlus(7),importance:4,effort:2,status:'Not Started',collegeSource:{courseId:cid,moduleId:mid,topic},checkpoints:[{id:uid(),title:`Understand ${topic}`,done:false},{id:uid(),title:`Practice ${topic}`,done:false},{id:uid(),title:`Review ${topic}`,done:false}]};state.activities.push(a);save();view='priority';render()}
function settingsView(){const keys=(state.apiKeys||[]).map((k,i)=>`<div class="activity"><div class="row"><div><b>${escape(k.provider)}</b><div class="subtle">${escape(k.masked)}</div></div><span class="pill">AI ready</span></div><button class="btn danger" style="margin-top:10px" onclick="removeKey(${i})">Remove</button></div>`).join("");return `<section class="card"><h2 style="margin:0">Settings</h2><div class="subtle">AI and notification controls</div><div class="stack" style="margin-top:16px"><div class="muted-box"><b>Server</b><div class="subtle">${serverReachable?"Connected — this device is synced to the shared CCED database.":"Not connected — using a local, unsynced copy until the server is reachable."}</div></div><div class="muted-box"><b>AI API keys</b><div class="subtle">Paste your provider key below. It is stored in the shared CCED database.</div></div><select class="input" id="keyProvider"><option>OpenRouter</option></select><input class="input" id="keyValue" type="password" placeholder="Paste API key"><input class="input" id="aiModel" placeholder="Model (e.g. openai/gpt-4o-mini)" value="${escape(state.settings.aiModel||"openai/gpt-4o-mini")}"><button class="btn dark" onclick="saveKey()">Save API key</button>${keys||'<div class="empty">No API keys saved.</div>'}<div class="muted-box"><div class="row"><div><b>Notifications</b><div class="subtle">Browser deadline reminders</div></div><input type="checkbox" ${state.settings.notificationsEnabled?"checked":""} onchange="toggleNotifications(this.checked)"></div><button class="btn" style="margin-top:10px" onclick="testNotification()">Send test notification</button></div><div class="muted-box"><b>Notification inbox</b>${(state.notifications||[]).slice().reverse().map(n=>`<div style="padding-top:10px"><strong>${escape(n.title)}</strong><div class="subtle">${escape(n.body)}</div></div>`).join("")||'<div class="subtle" style="margin-top:8px">No reminders yet.</div>'}</div></div></section>`}
function formModal(title,initial={}){return `<div class="modal" id="modal"><div class="sheet"><div class="row"><h2 style="margin:0">${escape(title)}</h2><button class="btn" onclick="closeModal()">Close</button></div><div class="stack" style="margin-top:16px"><input class="input" id="fTitle" placeholder="Activity title" value="${escape(initial.title||"")}"><div class="two"><input class="input" id="fSubject" placeholder="Subject" value="${escape(initial.subject||"")}"><select class="input" id="fType"><option>Assignment</option><option>Submission</option><option>Project</option><option>Lab</option><option>Exam</option><option>Study task</option><option>Other</option></select></div><textarea class="textarea" id="fDesc" placeholder="Description">${escape(initial.description||"")}</textarea><input class="input" id="fDeadline" type="datetime-local" value="${initial.deadline?new Date(initial.deadline).toISOString().slice(0,16):""}"><div class="two"><input class="input" id="fImportance" type="number" min="1" max="5" value="3" placeholder="Importance 1–5"><input class="input" id="fEffort" type="number" min="1" max="10" value="3" placeholder="Effort hours"></div><button class="btn dark" onclick="createManual()">Create activity</button></div></div></div>`}
window.setView=v=>{view=v;render()}
window.pickDate=()=>{const i=document.createElement("input");i.type="date";i.value=selectedDateKey;i.style.position="fixed";i.style.opacity="0";document.body.appendChild(i);i.onchange=()=>{selectedDateKey=dateKeyFromInput(i.value);i.remove();render()};i.onblur=()=>setTimeout(()=>i.remove(),300);i.click()}
window.classAction=which=>{const x=scheduleNow()[which];if(!x){alert(which==="current"?"No class is active right now.":"No upcoming class today.");return}app.insertAdjacentHTML("beforeend",`<div class="modal" id="modal"><div class="sheet"><div class="row"><div><h2 style="margin:0">${escape(x.subject)}</h2><div class="subtle">${which==="current"?"Live now":"Upcoming"} · ${x.start}–${x.end}</div></div><button class="btn" onclick="closeModal()">Close</button></div><div class="muted-box" style="margin-top:16px">${escape(x.room||"Room not set")}</div><button class="btn dark" style="margin-top:12px;width:100%" onclick="closeModal();openAI()">✦ Ask AI about this class</button></div></div>`)}
window.openActivity=id=>{const a=state.activities.find(x=>x.id===id);if(!a)return;app.insertAdjacentHTML("beforeend",`<div class="modal" id="modal"><div class="sheet"><div class="row"><div><h2 style="margin:0">${escape(a.title)}</h2><div class="subtle">${escape(a.subject)} · ${escape(a.type)}</div></div><button class="btn" onclick="closeModal()">Close</button></div><p>${escape(a.description)}</p><div class="muted-box"><b>Deadline</b><div>${new Date(a.deadline).toLocaleString("en-IN",{timeZone:TZ})} IST · ${dueText(a.deadline)}</div></div><h3>Checkpoints</h3>${(a.checkpoints||[]).map(c=>`<label class="check"><input type="checkbox" ${c.done?"checked":""} onchange="toggleCheck('${a.id}','${c.id}',this.checked)"><span>${escape(c.title)}</span></label>`).join("")}<div class="progress"><i style="width:${progress(a)}%"></i></div><div class="row"><b>${progress(a)}% complete</b><span class="pill ${priorityLabel(priority(a))[1]}">${priorityLabel(priority(a))[0]}</span></div><div class="row" style="margin-top:18px"><button class="btn" onclick="addCheckpoint('${a.id}')">+ Checkpoint</button><button class="btn danger" onclick="deleteActivity('${a.id}')">Delete</button></div></div></div>`)}
window.toggleCheck=(aid,cid,val)=>{const a=state.activities.find(x=>x.id===aid);if(!a)return;const c=(a.checkpoints||[]).find(x=>x.id===cid);if(!c)return;c.done=val;if(progress(a)===100)a.status="Completed";else if(progress(a)>0)a.status="In Progress";save();closeModal();render();openActivity(aid)}
window.addCheckpoint=aid=>{const t=prompt("Checkpoint name");if(!t)return;const a=state.activities.find(x=>x.id===aid);if(!a)return;a.checkpoints.push({id:uid(),title:t,done:false});save();closeModal();render();openActivity(aid)}
window.deleteActivity=aid=>{if(confirm("Delete this activity?")){state.activities=state.activities.filter(a=>a.id!==aid);save();closeModal();render()}}
window.closeModal=()=>document.querySelector("#modal")?.remove()
window.manualActivity=()=>{app.insertAdjacentHTML("beforeend",formModal("Create activity"))}
window.createManual=()=>{const title=document.querySelector("#fTitle").value.trim();if(!title)return alert("Add a title.");const a={id:uid(),title,subject:document.querySelector("#fSubject").value.trim()||"General",type:document.querySelector("#fType").value,description:document.querySelector("#fDesc").value.trim(),deadline:new Date(document.querySelector("#fDeadline").value||datePlus(7)).toISOString(),importance:Number(document.querySelector("#fImportance").value)||3,effort:Number(document.querySelector("#fEffort").value)||3,status:"Not Started",checkpoints:[]};state.activities.push(a);save();closeModal();render()}
window.addClass=()=>{app.insertAdjacentHTML("beforeend",`<div class="modal" id="modal"><div class="sheet"><div class="row"><div><h2 style="margin:0">Add timetable class</h2><div class="subtle">Choose the day and time.</div></div><button class="btn" onclick="closeModal()">Close</button></div><div class="stack" style="margin-top:16px"><input class="input" id="tSubject" placeholder="Subject"><div class="two"><select class="input" id="tDay"><option value="1">Monday</option><option value="2">Tuesday</option><option value="3">Wednesday</option><option value="4" selected>Thursday</option><option value="5">Friday</option><option value="6">Saturday</option><option value="0">Sunday</option></select><input class="input" id="tRoom" placeholder="Room"></div><div class="two"><label class="muted-box">Start<input class="input" id="tStart" type="time" value="09:00"></label><label class="muted-box">End<input class="input" id="tEnd" type="time" value="10:00"></label></div><button class="btn dark" onclick="saveClass()">Add to timetable</button></div></div></div>`)}
window.saveClass=()=>{const subject=document.querySelector("#tSubject").value.trim(),start=document.querySelector("#tStart").value,end=document.querySelector("#tEnd").value;if(!subject)return alert("Add a subject.");if(!start||!end||end<=start)return alert("Choose a valid start and end time.");state.timetable.push({id:uid(),day:Number(document.querySelector("#tDay").value),start,end,subject,room:document.querySelector("#tRoom").value.trim()});save();closeModal();render()}
window.deleteClass=id=>{const x=state.timetable.find(t=>t.id===id);if(!x)return;if(confirm(`Delete ${x.subject} from ${DAYS[x.day]}?`)){state.timetable=state.timetable.filter(t=>t.id!==id);save();render()}}
window.saveKey=async()=>{const p=document.querySelector("#keyProvider").value.trim()||"OpenRouter",v=document.querySelector("#keyValue").value.trim(),model=document.querySelector("#aiModel").value.trim()||"openai/gpt-4o-mini";if(!v)return alert("Paste an API key first.");state.settings.aiProvider=p;state.settings.aiModel=model;state.apiKeys=state.apiKeys.filter(k=>k.provider!==p);state.apiKeys.push({provider:p,key:v,masked:v.slice(0,4)+"••••••••"+v.slice(-4)});save();await ensureNotificationPermission();render()}
window.removeKey=i=>{state.apiKeys.splice(i,1);save();render()}
window.toggleNotifications=async v=>{state.settings.notificationsEnabled=v;save();if(v)await ensureNotificationPermission();render()}
window.testNotification=async()=>{if(!state.settings.notificationsEnabled){alert("Enable notifications first.");return}const permission=await ensureNotificationPermission();if(permission!=="granted"){alert("Notification permission was not granted. Check your browser/site notification settings.");return}await showSystemNotification("CCED test","Notifications are working.","cced-test-"+Date.now())}
function currentApiKey(){return (state.apiKeys||[]).find(k=>k.provider===(state.settings.aiProvider||"OpenRouter"))?.key||null}
async function callOpenRouter(messages){const key=currentApiKey();if(!key)throw new Error("No OpenRouter API key is configured. Add one in Settings.");const model=state.settings.aiModel||"openai/gpt-4o-mini";const response=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`,"HTTP-Referer":location.origin,"X-Title":"CCED Academic OS"},body:JSON.stringify({model,messages,temperature:.2})});if(!response.ok)throw new Error(`OpenRouter error ${response.status}: ${await response.text()}`);const data=await response.json();return data.choices?.[0]?.message?.content||"No response returned."}
window.openAI=()=>{app.insertAdjacentHTML("beforeend",`<div class="modal" id="modal"><div class="sheet"><div class="row"><div><h2 style="margin:0">Talk to CCED</h2><div class="subtle">${currentApiKey()?"OpenRouter AI is connected.":"Mock AI is active — add an API key in Settings to enable live AI."}</div></div><button class="btn" onclick="closeModal()">Close</button></div><textarea class="textarea" id="aiText" style="margin-top:16px" placeholder='Example: "I need to submit my physics record next Monday. Finish experiment 4, write observation, complete record and submit it."'></textarea><button class="btn dark" style="margin-top:10px;width:100%" onclick="interpretAI()">Interpret</button><div id="aiResult" style="margin-top:14px"></div></div></div>`)}
function nextWeekdayISO(name){
  const target=DAYS.findIndex(d=>d.toLowerCase()===String(name||"").toLowerCase());
  if(target<0)return null;
  const now=new Date();
  const current=dayForKey(todayKey());
  let delta=(target-current+7)%7;
  if(delta===0)delta=7;
  const p=partsInIST(new Date(now.getTime()+delta*86400000));
  return `${p.year}-${p.month}-${p.day}T23:59:00+05:30`;
}
function resolveDeadline(value){
  if(!value)return null;
  const v=String(value).trim().toLowerCase();
  if(v==='today'){const k=todayKey();return `${k}T23:59:00+05:30`}
  if(v==='tomorrow'){const d=new Date(Date.now()+86400000),p=partsInIST(d);return `${p.year}-${p.month}-${p.day}T23:59:00+05:30`}
  const m=v.match(/(?:next\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)/);
  if(m)return nextWeekdayISO(m[1]);
  const iso=v.match(/(\d{4}-\d{2}-\d{2})/);if(iso)return `${iso[1]}T23:59:00+05:30`;
  return null;
}
function formatDeadlineIST(iso){
  try{return new Date(iso).toLocaleString("en-IN",{timeZone:TZ,day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit",hour12:true})+" IST"}catch{return String(iso)}
}
function stripMarkdown(s){
  return String(s||"").replace(/\*\*(.*?)\*\*/g,"$1").replace(/__(.*?)__/g,"$1").replace(/^\s*[-*•]\s*/,"").replace(/^\s*#+\s*/,"").trim();
}
function parseMarkdownProposal(text){
  const source=String(text||"").trim();
  const lines=source.split(/\r?\n/);
  const cleanLine=line=>String(line||"").trim().replace(/^\s*[-*•]\s*/,"").replace(/\*\*/g,"").trim();
  const field=(label)=>{
    const target=String(label).toLowerCase();
    for(const line of lines){
      const cleaned=cleanLine(line);
      const m=cleaned.match(/^([^:]+)\s*:\s*(.+)$/);
      if(m&&m[1].trim().toLowerCase()===target)return stripMarkdown(m[2]);
    }
    return "";
  };
  const title=field("Title");
  const subject=field("Subject")||"General";
  const type=field("Type")||"Task";
  const deadlineRaw=field("Deadline");
  const confidenceRaw=field("Confidence");
  const collectSection=(name,nextNames)=>{
    const target=String(name).toLowerCase();
    let active=false,items=[];
    for(const line of lines){
      const cleaned=cleanLine(line);
      const m=cleaned.match(/^([^:]+)\s*:\s*(.*)$/);
      if(m){
        const label=m[1].trim().toLowerCase();
        if(label===target){active=true;if(m[2].trim())items.push(m[2].trim());continue}
        if(active&&nextNames.map(x=>x.toLowerCase()).includes(label))break;
      }else if(active&&cleaned) items.push(cleaned);
    }
    return items;
  };
  const checkpoints=collectSection("Checkpoints",["Ambiguities","Confidence"])
    .map(x=>stripMarkdown(x).replace(/^\d+[.)]\s*/,"")).filter(Boolean).slice(0,12);
  const ambiguities=collectSection("Ambiguities",["Confidence"])
    .map(x=>stripMarkdown(x)).filter(Boolean).filter(x=>!/^(none|n\/a)$/i.test(x)).slice(0,6);
  const confidence=parseFloat((confidenceRaw.match(/[0-9.]+/)||[])[0])||0.5;
  if(!title)return null;
  return {title,subject,type,deadline:resolveDeadline(deadlineRaw),checkpoints:checkpoints.map(title=>({id:uid(),title,done:false})),ambiguities,confidence,text:source};
}
function normalizeProposal(raw,text){
  let obj=raw;
  if(typeof obj==='string'){
    const cleaned=obj.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
    try{obj=JSON.parse(cleaned)}catch{
      const match=cleaned.match(/\{[\s\S]*\}/);
      if(match){try{obj=JSON.parse(match[0])}catch{obj=null}}
    }
    if(!obj) obj=parseMarkdownProposal(cleaned);
  }
  if(!obj||typeof obj!=='object') throw new Error('AI response could not be converted into an activity proposal.');
  if(!obj.title && typeof raw==="string") obj=parseMarkdownProposal(raw);
  if(!obj||!String(obj.title||"").trim()) throw new Error('AI proposal is missing a title.');
  const title=String(obj.title).trim();
  const subject=String(obj.subject||'General').trim()||'General';
  const type=String(obj.type||'Task').trim()||'Task';
  const deadline=resolveDeadline(obj.deadline)||resolveDeadline(String(text).match(/(?:today|tomorrow|next\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday))/i)?.[0]);
  const checkpoints=Array.isArray(obj.checkpoints)?obj.checkpoints.map(x=>typeof x==='string'?x:String(x?.title||'')).filter(Boolean).slice(0,12).map(title=>({id:uid(),title,done:false})):[];
  const ambiguities=Array.isArray(obj.ambiguities)?obj.ambiguities.filter(Boolean).slice(0,6):[];
  return {title,subject,type,deadline,checkpoints,ambiguities,confidence:Number(obj.confidence)||0.5,text:String(text||'')};
}
function proposalHTML(obj){
  currentAIProposal=obj;
  const deadlineText=obj.deadline?`${formatDeadlineIST(obj.deadline)} · ${dueText(obj.deadline)}`:"No deadline detected";
  const pct=obj.checkpoints.length?Math.round(obj.checkpoints.filter(c=>c.done).length/obj.checkpoints.length*100):0;
  return `<div class="muted-box"><div class="pill high">CCED ACTION PLAN</div><h3 style="margin:10px 0 5px">${escape(obj.title)}</h3><div class="subtle">${escape(obj.subject)} · ${escape(obj.type)}</div><div class="muted-box" style="margin-top:10px"><b>Deadline</b><div>${escape(deadlineText)}</div></div><b style="display:block;margin-top:14px">What CCED will track</b>${obj.checkpoints.length?`<div style="margin-top:6px">${obj.checkpoints.map((c,i)=>`<label class="check"><input type="checkbox" ${c.done?'checked':''} onchange="toggleAIProposalCheck(${i},this.checked)"><span>${escape(c.title)}</span></label>`).join('')}</div>`:'<div class="subtle" style="margin-top:8px">No checkpoints were detected. You can add them after creation.</div>'}<div class="progress"><i style="width:${pct}%"></i></div><div class="row"><small>${pct}% complete</small><small>AI confidence ${Math.round((obj.confidence||.5)*100)}%</small></div>${obj.ambiguities.length?`<div class="pill high" style="margin-top:10px">${escape(obj.ambiguities.join(' · '))}</div>`:''}<div class="row" style="margin-top:14px"><button class="btn" onclick="closeModal()">Cancel</button><button class="btn dark" onclick="confirmAI()">Create priority</button></div></div>`;
}
window.toggleAIProposalCheck=(index,val)=>{if(!currentAIProposal?.checkpoints?.[index])return;currentAIProposal.checkpoints[index].done=Boolean(val);const result=document.querySelector("#aiResult");if(result)result.innerHTML=proposalHTML(currentAIProposal)};
window.interpretAI=async()=>{
 const text=document.querySelector('#aiText').value.trim();if(!text)return;
 const result=document.querySelector('#aiResult');result.innerHTML='<div class="muted-box">Thinking…</div>';
 if(currentApiKey()){
  try{
   const reply=await callOpenRouter([{role:'system',content:'You are CCED, an academic operating system. Return ONLY valid JSON, no markdown and no prose. Schema: {"title":string,"subject":string,"type":string,"deadline":string|null,"checkpoints":string[],"ambiguities":string[],"confidence":number}. deadline must be one of today, tomorrow, next Monday, next Tuesday, next Wednesday, next Thursday, next Friday, next Saturday, next Sunday, or YYYY-MM-DD when the user supplied a date. Extract concrete academic work and checkpoints. Never claim the activity was created; CCED will create it only after user confirmation.'},{role:'user',content:text}]);
   const proposal=normalizeProposal(reply,text);result.innerHTML=proposalHTML(proposal);return;
  }catch(err){result.innerHTML=`<div class="muted-box"><b>Live AI failed</b><p>${escape(err.message)}</p><div class="subtle">CCED remains usable with manual activity creation.</div></div>`;return;}
 }
 const low=text.toLowerCase(),subject=low.includes('physics')?'Physics':low.includes('chemistry')?'Chemistry':low.includes('math')?'Engineering Mathematics':low.includes('program')?'Programming':'General';
 const title=low.includes('record')?`${subject} Record`:low.includes('assignment')?`${subject} Assignment`:`${subject} Activity`;
 const words=text.match(/(?:experiment|observation|record|review|submit|assignment|project)[^,.]*(?:,| and |$)/gi)||[];
 const names=[...new Set(words.map(x=>x.replace(/[,]+$/i,'').trim()))];
 const checkpoints=(names.length?names:['Complete work','Review','Submit']).slice(0,6).map(x=>({id:uid(),title:x[0].toUpperCase()+x.slice(1),done:false}));
 const dateMatch=low.match(/(?:today|tomorrow|next\s+(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday))/i);
 const deadline=resolveDeadline(dateMatch?.[0]);
 const proposal={title,subject,type:'Task',deadline,checkpoints,ambiguities:deadline?[]:['Exact deadline was not detected.'],confidence:deadline?.5+.3:.4,text};
 result.innerHTML=proposalHTML(proposal);
};
window.confirmAI=()=>{
  const obj=currentAIProposal;
  if(!obj||!obj.title){alert('The AI proposal is incomplete. Please try again.');return}
  if(!obj.deadline){alert('Please give CCED a clear deadline, such as "next Monday", before adding this activity.');return}
  const activity={id:uid(),schemaVersion:1,source:"ai",title:String(obj.title),description:`AI-created plan for ${String(obj.subject||"General")}.`,subject:String(obj.subject||"General"),type:String(obj.type||"Task"),deadline:new Date(obj.deadline).toISOString(),importance:4,effort:3,status:"Not Started",checkpoints:Array.isArray(obj.checkpoints)?obj.checkpoints.map(c=>({id:c.id||uid(),title:String(c.title),done:Boolean(c.done)})):[]};
  state.activities.push(activity);currentAIProposal=null;save();closeModal();view='priority';render();
};
function registerSW(){if("serviceWorker"in navigator)navigator.serviceWorker.register("./sw.js",{scope:"./"}).then(r=>r.update()).catch(()=>{})}
function updateLiveHome(){
  if(view!=="today") return;
  const clock=document.querySelector("#cced-clock");
  if(clock) clock.textContent=istClock();
  const nowParts=partsInIST();
  const minute=`${nowParts.year}-${nowParts.month}-${nowParts.day} ${nowParts.hour}:${nowParts.minute}`;
  if(minute===lastLiveMinute)return;
  lastLiveMinute=minute;
  const {current,next}=scheduleNow(),isToday=selectedDateKey===todayKey();
  const currentCard=document.querySelector("#cced-current-card"),nextCard=document.querySelector("#cced-next-card");
  if(currentCard) currentCard.innerHTML=`<h3 class="section-title">CURRENT</h3>${current?`<div><strong>${escape(current.subject)}</strong><div class="subtle">${current.start}–${current.end} · ${escape(current.room)}</div><div class="pill" style="margin-top:10px">● Live now</div></div>`:`<div class="empty">${isToday?"No class right now.":"Current session is only live for today."}</div>`}`;
  if(nextCard) nextCard.innerHTML=`<h3 class="section-title">NEXT</h3>${next?`<div><strong>${escape(next.subject)}</strong><div class="subtle">${next.start}–${next.end} · ${escape(next.room)}</div><div class="pill" style="margin-top:10px">Upcoming</div></div>`:`<div class="empty">${isToday?"No more classes today.":"No upcoming session for this selected date."}</div>`}`;
}
function tick(){
  const k=todayKey();
  if(k!==selectedDateKey){selectedDateKey=k;if(view==="today"){lastLiveMinute="";render();return}}
  updateLiveHome();
  refreshNotifications();
  if(Date.now()%60000<1100)fireNotifications();
}
loadFromServer().then(()=>{ registerSW(); setInterval(tick,1000); });
