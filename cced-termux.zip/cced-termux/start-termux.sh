#!/data/data/com.termux/files/usr/bin/bash
# CCED for Termux — zero dependencies, nothing to pip install.
#
# Usage:
#   bash start-termux.sh
#
# Then open, on this phone:
#   http://localhost:8000
# Or from another device on the same WiFi:
#   http://<this phone's LAN IP>:8000
# Find the LAN IP with: ip addr   (look for the wlan0 inet address)

cd "$(dirname "$0")/backend"
echo "Starting CCED (Termux, no-dependency build)..."
python server.py
