"""
CCED backend — zero external dependencies.

Uses only Python's standard library (http.server + sqlite3), so there is
NOTHING to pip install. This avoids the pydantic-core/Rust compilation
problem that FastAPI's stack runs into on Termux (aarch64-linux-android
isn't a Rust target rustup supports out of the box).

Run with:
    python server.py

Then open:
    http://localhost:8000            (same device)
    http://<this-device-LAN-IP>:8000 (another device, same WiFi)
"""

import json
import sqlite3
import threading
import mimetypes
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = Path(__file__).parent
DB_PATH = HERE / "cced.db"
FRONTEND_DIR = HERE.parent  # index.html, src/, sw.js etc. live one level up

SEED_STATE = {
    "timetable": [
        {"id": "t1", "day": 4, "start": "09:00", "end": "10:00", "subject": "Programming", "room": "Lab 1"},
        {"id": "t2", "day": 4, "start": "10:15", "end": "11:15", "subject": "Engineering Mathematics", "room": "A-204"},
        {"id": "t3", "day": 4, "start": "11:30", "end": "12:30", "subject": "Physics", "room": "B-102"},
        {"id": "t4", "day": 5, "start": "09:00", "end": "10:00", "subject": "Digital Electronics", "room": "A-201"},
    ],
    "apiKeys": [],
    "notifications": [],
    "collegeProgress": {},
    "settings": {"notificationsEnabled": True, "aiProvider": "OpenRouter", "aiModel": "openai/gpt-4o-mini"},
    "activities": [],
}

_lock = threading.Lock()


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS app_state ("
        "  id INTEGER PRIMARY KEY CHECK (id = 1),"
        "  data TEXT NOT NULL,"
        "  updated_at TEXT DEFAULT CURRENT_TIMESTAMP"
        ")"
    )
    conn.commit()
    return conn


def read_state() -> dict:
    conn = get_conn()
    try:
        row = conn.execute("SELECT data FROM app_state WHERE id = 1").fetchone()
        if row is None:
            conn.execute("INSERT INTO app_state (id, data) VALUES (1, ?)", (json.dumps(SEED_STATE),))
            conn.commit()
            return json.loads(json.dumps(SEED_STATE))
        return json.loads(row[0])
    finally:
        conn.close()


def write_state(state: dict) -> None:
    conn = get_conn()
    try:
        conn.execute(
            "INSERT INTO app_state (id, data, updated_at) VALUES (1, ?, CURRENT_TIMESTAMP) "
            "ON CONFLICT(id) DO UPDATE SET data = excluded.data, updated_at = CURRENT_TIMESTAMP",
            (json.dumps(state),),
        )
        conn.commit()
    finally:
        conn.close()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # keep terminal output quiet; remove this to see request logs

    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path: Path):
        if not path.exists() or not path.is_file():
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found")
            return
        content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, PUT, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path == "/api/state":
            with _lock:
                self._send_json(read_state())
            return
        if self.path == "/api/health":
            self._send_json({"ok": True})
            return

        # Static file serving for the frontend
        rel = self.path.split("?")[0]
        if rel == "/":
            rel = "/index.html"
        file_path = (FRONTEND_DIR / rel.lstrip("/")).resolve()
        # Prevent escaping the frontend directory
        if FRONTEND_DIR.resolve() not in file_path.parents and file_path != FRONTEND_DIR.resolve():
            self.send_response(403)
            self.end_headers()
            return
        self._send_file(file_path)

    def do_PUT(self):
        if self.path == "/api/state":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                self._send_json({"error": "invalid JSON"}, status=400)
                return
            if not isinstance(data, dict):
                self._send_json({"error": "state must be an object"}, status=400)
                return
            with _lock:
                write_state(data)
            self._send_json({"ok": True})
            return
        self.send_response(404)
        self.end_headers()


if __name__ == "__main__":
    port = 8000
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"CCED server running at http://0.0.0.0:{port}")
    print(f"  On this device:      http://localhost:{port}")
    print(f"  On another device:   http://<this device's LAN IP>:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
